//
//  SurveyObject.m
//  Project
//
//  Created by Adam on 14-5-27.
//  Copyright (c) 2014年 com.jit. All rights reserved.
//

#import "SurveyObject.h"

@implementation SurveyObject

@end
